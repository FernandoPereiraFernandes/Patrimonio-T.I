#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."

LOGFILE="/tmp/patrimonioti-update.log"
echo "[$(date '+%Y-%m-%d %H:%M:%S')] Iniciando atualização..." > "$LOGFILE"

echo "==> git fetch" >> "$LOGFILE"
git fetch origin >> "$LOGFILE" 2>&1

echo "==> git pull" >> "$LOGFILE"
git pull origin main >> "$LOGFILE" 2>&1

echo "==> bun install" >> "$LOGFILE"
bun install >> "$LOGFILE" 2>&1

echo "==> prisma generate" >> "$LOGFILE"
bunx prisma generate >> "$LOGFILE" 2>&1

echo "==> prisma db push (aplica alterações de schema)" >> "$LOGFILE"
bunx prisma db push >> "$LOGFILE" 2>&1

echo "==> build" >> "$LOGFILE"
bun run build >> "$LOGFILE" 2>&1

echo "[$(date '+%Y-%m-%d %H:%M:%S')] Atualização concluída. Reinicie o processo (bun run start) para aplicar." >> "$LOGFILE"
