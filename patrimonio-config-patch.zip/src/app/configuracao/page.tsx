"use client";

import { useEffect, useState } from "react";
import { useSession } from "next-auth/react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { toast } from "sonner";
import {
  Settings,
  RefreshCw,
  Download,
  Shield,
  GitBranch,
  CheckCircle2,
  Loader2,
  AlertTriangle,
} from "lucide-react";

interface UpdateStatus {
  branch: string;
  localHash: string;
  remoteHash: string;
  upToDate: boolean;
  commitsPendentes: { hash: string; message: string; author: string; date: string }[];
}

export default function ConfiguracaoPage() {
  const { data: session } = useSession();
  const qc = useQueryClient();
  const [updating, setUpdating] = useState(false);
  const [log, setLog] = useState("");

  const isAdmin = session?.user?.role === "ADMIN";

  const { data: status, isLoading, refetch, isFetching } = useQuery<UpdateStatus>({
    queryKey: ["update-status"],
    queryFn: async () => {
      const res = await fetch("/api/config/status");
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.error || "Erro ao verificar atualizações");
      }
      return res.json();
    },
    enabled: isAdmin,
  });

  const updateMut = useMutation({
    mutationFn: async () => {
      const res = await fetch("/api/config/update", { method: "POST" });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.error || "Erro ao iniciar atualização");
      }
      return res.json();
    },
    onSuccess: () => {
      setUpdating(true);
      toast.success("Atualização iniciada. Acompanhe o log abaixo.");
    },
    onError: (e) => toast.error(e instanceof Error ? e.message : "Erro"),
  });

  // Poll do log enquanto está atualizando
  useEffect(() => {
    if (!updating) return;
    const interval = setInterval(async () => {
      const res = await fetch("/api/config/update-log");
      if (res.ok) {
        const data = await res.json();
        setLog(data.log);
        if (data.done) {
          setUpdating(false);
          clearInterval(interval);
          qc.invalidateQueries({ queryKey: ["update-status"] });
        }
      }
    }, 2000);
    return () => clearInterval(interval);
  }, [updating, qc]);

  if (!isAdmin) {
    return (
      <div className="flex flex-col items-center justify-center py-20">
        <Shield className="size-12 text-muted-foreground/40" />
        <h2 className="mt-4 text-lg font-medium">Acesso restrito</h2>
        <p className="text-sm text-muted-foreground mt-1">
          Apenas administradores podem acessar a Configuração.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div>
        <h2 className="text-xl font-semibold tracking-tight flex items-center gap-2">
          <Settings className="size-5 text-primary" />
          Configuração do Sistema
        </h2>
        <p className="text-sm text-muted-foreground">
          Verifique e aplique atualizações vindas do repositório no GitHub.
        </p>
      </div>

      <Card className="p-4 space-y-2 border-amber-200 bg-amber-50 dark:bg-amber-900/20 dark:border-amber-800">
        <div className="flex items-start gap-2 text-amber-800 dark:text-amber-300 text-sm">
          <AlertTriangle className="size-4 mt-0.5 shrink-0" />
          <div>
            <p className="font-medium">
              Este servidor está rodando via <code>bun run dev</code> manual.
            </p>
            <p className="mt-1">
              A atualização baixa e recompila o novo código, mas{" "}
              <strong>não reinicia o processo sozinha</strong>. Quando o log
              indicar &quot;concluída&quot;, pare o terminal atual (Ctrl+C) e
              rode <code className="px-1 py-0.5 rounded bg-black/10 dark:bg-white/10">bun run start</code>{" "}
              novamente. Para produção, recomendo configurar o serviço systemd
              (<code className="px-1 py-0.5 rounded bg-black/10 dark:bg-white/10">
                scripts/patrimonioti.service
              </code>
              ) para reinício automático.
            </p>
          </div>
        </div>
      </Card>

      <Card className="p-4 space-y-4">
        {isLoading ? (
          <Skeleton className="h-20 w-full" />
        ) : status ? (
          <>
            <div className="flex flex-wrap items-center gap-3">
              <div className="flex items-center gap-2 text-sm">
                <GitBranch className="size-4 text-muted-foreground" />
                <span className="font-medium">{status.branch}</span>
              </div>
              <Badge variant="outline" className="font-mono text-xs">
                local: {status.localHash}
              </Badge>
              <Badge variant="outline" className="font-mono text-xs">
                GitHub: {status.remoteHash}
              </Badge>
              {status.upToDate ? (
                <Badge className="bg-emerald-100 text-emerald-700 border-emerald-200">
                  <CheckCircle2 className="size-3 mr-1" />
                  Atualizado
                </Badge>
              ) : (
                <Badge className="bg-amber-100 text-amber-700 border-amber-200">
                  {status.commitsPendentes.length} commit(s) pendente(s)
                </Badge>
              )}
            </div>

            {status.commitsPendentes.length > 0 && (
              <div className="rounded-lg border divide-y max-h-56 overflow-y-auto custom-scroll">
                {status.commitsPendentes.map((c) => (
                  <div key={c.hash} className="p-2.5 text-sm">
                    <div className="flex items-center gap-2">
                      <code className="text-xs text-muted-foreground">{c.hash}</code>
                      <span className="font-medium">{c.message}</span>
                    </div>
                    <div className="text-xs text-muted-foreground mt-0.5">
                      {c.author} · {c.date}
                    </div>
                  </div>
                ))}
              </div>
            )}

            <div className="flex gap-2">
              <Button variant="outline" onClick={() => refetch()} disabled={isFetching}>
                <RefreshCw className={`size-4 mr-1 ${isFetching ? "animate-spin" : ""}`} />
                Verificar novamente
              </Button>
              <Button
                onClick={() => {
                  if (
                    confirm(
                      "Isso vai baixar o código mais recente do GitHub, instalar dependências e recompilar. Continuar?"
                    )
                  ) {
                    updateMut.mutate();
                  }
                }}
                disabled={status.upToDate || updating || updateMut.isPending}
              >
                {updating || updateMut.isPending ? (
                  <Loader2 className="size-4 mr-1 animate-spin" />
                ) : (
                  <Download className="size-4 mr-1" />
                )}
                Aplicar atualização
              </Button>
            </div>
          </>
        ) : null}

        {(updating || log) && (
          <div className="mt-2">
            <p className="text-xs font-medium text-muted-foreground mb-1">
              Log da atualização:
            </p>
            <pre className="bg-black text-emerald-400 text-xs p-3 rounded-lg max-h-64 overflow-y-auto whitespace-pre-wrap">
              {log || "Aguardando início..."}
            </pre>
          </div>
        )}
      </Card>
    </div>
  );
}
