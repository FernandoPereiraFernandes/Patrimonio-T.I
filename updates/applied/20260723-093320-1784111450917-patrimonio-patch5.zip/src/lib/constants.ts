// Constantes do sistema de patrimônio de TI

export type CategoriaAtivo =
  | "MONITOR"
  | "CPU"
  | "NOTEBOOK"
  | "TV"
  | "RACK"
  | "SERVIDOR"
  | "IMPRESSORA"
  | "IMPRESSORA_ZEBRA"
  | "SMARTPHONE"
  | "TELEFONE_FIXO";

export type StatusAtivo =
  | "EM_ESTOQUE"
  | "EM_USO"
  | "EM_MANUTENCAO"
  | "DESCARTADO";

export type TipoMovimentacao =
  | "ENTRADA_ESTOQUE"
  | "ATRIBUICAO"
  | "DEVOLUCAO"
  | "MANUTENCAO"
  | "DESCARTE"
  | "TRANSFERENCIA";

export interface CategoriaInfo {
  value: CategoriaAtivo;
  label: string;
  labelSingular: string;
  icon: string; // nome do ícone lucide
  // campos específicos sugeridos para essa categoria
  campos: string[];
}

export const CATEGORIAS: CategoriaInfo[] = [
  {
    value: "MONITOR",
    label: "Monitores",
    labelSingular: "Monitor",
    icon: "Monitor",
    campos: ["Polegadas", "Resolução", "Tipo de painel", "Conexões"],
  },
  {
    value: "CPU",
    label: "CPUs / Desktops",
    labelSingular: "CPU",
    icon: "Cpu",
    campos: ["Processador", "Memória RAM", "Armazenamento", "Sistema Operacional"],
  },
  {
    value: "NOTEBOOK",
    label: "Notebooks",
    labelSingular: "Notebook",
    icon: "Laptop",
    campos: ["Processador", "Memória RAM", "Armazenamento", "Tela", "Sistema Operacional"],
  },
  {
    value: "TV",
    label: "Televisões",
    labelSingular: "TV",
    icon: "Tv",
    campos: ["Polegadas", "Resolução", "Tipo", "Smart TV"],
  },
  {
    value: "RACK",
    label: "Racks",
    labelSingular: "Rack",
    icon: "Server",
    campos: ["Tamanho (U)", "Largura", "Ventilação", "Capacidade"],
  },
  {
    value: "SERVIDOR",
    label: "Servidores",
    labelSingular: "Servidor",
    icon: "HardDrive",
    campos: ["Processador", "Memória RAM", "Armazenamento", "Sistema Operacional", "Função"],
  },
  {
    value: "IMPRESSORA",
    label: "Impressoras",
    labelSingular: "Impressora",
    icon: "Printer",
    campos: ["Tipo", "Velocidade (ppm)", "Duplex", "Conectividade"],
  },
  {
    value: "IMPRESSORA_ZEBRA",
    label: "Impressoras Térmicas Zebra",
    labelSingular: "Impressora Térmica Zebra",
    icon: "Printer",
    campos: ["Modelo", "Resolução (dpi)", "Largura máxima", "Conectividade", "Uso"],
  },
  {
    value: "SMARTPHONE",
    label: "Smartphones",
    labelSingular: "Smartphone",
    icon: "Smartphone",
    campos: ["Armazenamento", "RAM", "Sistema Operacional", "Linha/Operadora"],
  },
  {
    value: "TELEFONE_FIXO",
    label: "Telefones Fixos",
    labelSingular: "Telefone Fixo",
    icon: "Phone",
    campos: ["Tipo", "Ramal", "Linhas", "Recursos"],
  },
];

export const STATUS: { value: StatusAtivo; label: string; color: string; variant: "default" | "secondary" | "destructive" | "outline" }[] = [
  { value: "EM_ESTOQUE", label: "Em Estoque", color: "slate", variant: "secondary" },
  { value: "EM_USO", label: "Em Uso", color: "emerald", variant: "default" },
  { value: "EM_MANUTENCAO", label: "Em Manutenção", color: "amber", variant: "outline" },
  { value: "DESCARTADO", label: "Descartado", color: "rose", variant: "destructive" },
];

export const TIPOS_MOVIMENTACAO: { value: TipoMovimentacao; label: string; color: string }[] = [
  { value: "ENTRADA_ESTOQUE", label: "Entrada em Estoque", color: "slate" },
  { value: "ATRIBUICAO", label: "Atribuição a Responsável", color: "emerald" },
  { value: "DEVOLUCAO", label: "Devolução ao Estoque", color: "cyan" },
  { value: "MANUTENCAO", label: "Envio para Manutenção", color: "amber" },
  { value: "DESCARTE", label: "Descarte", color: "rose" },
  { value: "TRANSFERENCIA", label: "Transferência de Local", color: "violet" },
];

export function getCategoria(value: string): CategoriaInfo | undefined {
  return CATEGORIAS.find((c) => c.value === value);
}

export function getCategoriaLabel(value: string): string {
  return getCategoria(value)?.labelSingular ?? value;
}

export function getStatusInfo(value: string) {
  return STATUS.find((s) => s.value === value);
}

export function getTipoMovimentacaoInfo(value: string) {
  return TIPOS_MOVIMENTACAO.find((t) => t.value === value);
}

// Cores por categoria para gráficos (categorias padrão do sistema)
export const CATEGORIA_COLORS: Record<string, string> = {
  MONITOR: "#10b981", // emerald
  CPU: "#0ea5e9", // sky
  NOTEBOOK: "#8b5cf6", // violet
  TV: "#f59e0b", // amber
  RACK: "#64748b", // slate
  SERVIDOR: "#ef4444", // red
  IMPRESSORA: "#ec4899", // pink
  IMPRESSORA_ZEBRA: "#14b8a6", // teal
  SMARTPHONE: "#84cc16", // lime
  TELEFONE_FIXO: "#f97316", // orange
};

// Paleta de reserva (hex) para categorias sem cor definida em CATEGORIA_COLORS.
// Usar hex (e não hsl()) é proposital: alguns componentes concatenam alpha
// manualmente (ex: `${cor}22`), o que só funciona com hex.
const PALETA_FALLBACK = [
  "#10b981", "#0ea5e9", "#8b5cf6", "#f59e0b", "#ef4444",
  "#ec4899", "#14b8a6", "#84cc16", "#f97316", "#6366f1",
  "#06b6d4", "#a855f7", "#eab308", "#22c55e", "#f43f5e",
];

// Gera uma cor determinística para categorias que não estão em CATEGORIA_COLORS
// (ex: categorias customizadas criadas pelo admin). Assim gráficos nunca
// mostram todas as categorias novas na mesma cor.
export function getCategoriaColor(value: string): string {
  const fixa = CATEGORIA_COLORS[value];
  if (fixa) return fixa;

  let hash = 0;
  for (let i = 0; i < value.length; i++) {
    hash = value.charCodeAt(i) + ((hash << 5) - hash);
  }
  return PALETA_FALLBACK[Math.abs(hash) % PALETA_FALLBACK.length];
}

// Ordenação numérica "natural" para números de patrimônio (ex: TI-MON-0001,
// TI-MON-0002, ..., TI-MON-0010). Uma ordenação alfabética comum colocaria
// "TI-MON-0010" antes de "TI-MON-0002" (porque "1" < "2" como caractere).
// Esta função quebra a string em pedaços de dígitos e não-dígitos, e compara
// os pedaços numéricos como números — assim 2 vem antes de 10 corretamente,
// mesmo com prefixos/sufixos de texto.
export function compareNumeroPatrimonio(a: string, b: string): number {
  const tokenize = (s: string): (string | number)[] => {
    const tokens: (string | number)[] = [];
    s.replace(/(\d+)|(\D+)/g, (_match, digits: string, texto: string) => {
      tokens.push(digits !== undefined ? parseInt(digits, 10) : texto);
      return "";
    });
    return tokens;
  };

  const ta = tokenize(a);
  const tb = tokenize(b);
  const len = Math.max(ta.length, tb.length);

  for (let i = 0; i < len; i++) {
    const va = ta[i];
    const vb = tb[i];
    if (va === undefined) return -1;
    if (vb === undefined) return 1;
    if (typeof va === "number" && typeof vb === "number") {
      if (va !== vb) return va - vb;
    } else {
      const sa = String(va);
      const sb = String(vb);
      if (sa !== sb) return sa < sb ? -1 : 1;
    }
  }
  return 0;
}
